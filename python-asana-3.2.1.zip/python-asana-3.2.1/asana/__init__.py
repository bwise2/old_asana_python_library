__title__ = 'asana'
__license__ = 'MIT'
__copyright__ = 'Copyright 2016 Asana, Inc.'

from asana.version import __version__
from .client import Client
