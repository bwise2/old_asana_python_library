
from .gen.project_templates import _ProjectTemplates

class ProjectTemplates(_ProjectTemplates):
    """ProjectTemplates resource"""
    pass
