from .gen.memberships import _Memberships

class Memberships(_Memberships):
    """Memberships resource"""
    pass
