
from .gen.message import _Message

class Message(_Message):
    """Message resource"""
    pass
