from .gen.goal_relationships import _GoalRelationships

class GoalRelationships(_GoalRelationships):
    """Goal relationships resource"""
    pass
