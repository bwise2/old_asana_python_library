
from .gen.time_periods import _TimePeriods

class TimePeriods(_TimePeriods):
    """TimePeriods resource"""
    pass
