
from .gen.workspace_memberships import _WorkspaceMemberships

class WorkspaceMemberships(_WorkspaceMemberships):
    """WorkspaceMemberships resource"""
    pass
