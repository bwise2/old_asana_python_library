
from .gen.team_memberships import _TeamMemberships

class TeamMemberships(_TeamMemberships):
    """TeamMemberships resource"""
    pass
