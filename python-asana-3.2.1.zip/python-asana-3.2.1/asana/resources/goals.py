
from .gen.goals import _Goals

class Goals(_Goals):
    """Goals resource"""
    pass
