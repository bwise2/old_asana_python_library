
from .gen.project_briefs import _ProjectBriefs

class ProjectBriefs(_ProjectBriefs):
    """ProjectBriefs resource"""
    pass
