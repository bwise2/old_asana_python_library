
from .gen.typeahead import _Typeahead

class Typeahead(_Typeahead):
    """Typeahead resource"""
    pass
