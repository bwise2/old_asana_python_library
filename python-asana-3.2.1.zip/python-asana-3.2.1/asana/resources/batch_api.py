
from .gen.batch_api import _BatchAPI

class BatchAPI(_BatchAPI):
    """BatchAPI resource"""
    pass
