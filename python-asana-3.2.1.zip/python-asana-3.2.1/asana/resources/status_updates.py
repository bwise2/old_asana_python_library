
from .gen.status_updates import _StatusUpdates

class StatusUpdates(_StatusUpdates):
    """Goals resource"""
    pass
